import axios from 'axios'
import { sticker } from '../lib/sticker.js'

let handler = m => m;
handler.all = async function (m) {
    // التحقق مما إذا كانت الرسالة مرسلة من البوت نفسه
    if (m.key.fromMe) {
        return; // إيقاف التنفيذ إذا كانت الرسالة مرسلة من البوت
    }

    let chat = global.db.data.chats[m.chat];
    let responses;
   if (/^دييييم$/i.test(m.text)) { 
     responses = [ 
 '*بعرف شايف 🙂‍↔️*'  
     ]; 
}else if (/^ولاشي|ولا شي$/i.test(m.text)) { 
     responses = [ 
'*طول الوقت هيك انت 🙂*',
'*ما بدك تسولف اطلع براحتك😖*'
     ]; 
}else if (/^وتفف|وتف$/i.test(m.text)) { 
     responses = [ 
'*شبك يمز😘*',
     ]; 
}else if (/^دزمها$/i.test(m.text)) { 
     responses = [ 
'*احيهه🗿*',
'*الـلـه يـسـامـحـك 🙂*',
'*قادح*',
     ]; 
     }else if (/^اهاا|اماا|افاا|ماااا|افااا|اهااا$/i.test(m.text)) { 
     responses = [ 
'*ليش تسلك 🌚🙂*'
     ]; 
} else if (/^وربي حلو|حلو وربي|حلوو حبيت|و ربي حلو$/i.test(m.text)) { 
     responses = [ 
       '*حلو مثلك 🥰*',  
     ]; 
     }else if (/^البوت ميت$/i.test(m.text)) { 
     responses = [ 
'*انت الميت🫵🏻*',
     ]; 
     }else if (/^يا ويلي$/i.test(m.text)) { 
     responses = [ 
'*بعدين شو😐*',
     ]; 
     }else if (/^عمو$/i.test(m.text)) { 
     responses = [ 
'*لساتو صغير ترا🫠*',
     ]; 
   }else if (/^اتفق|اتفقق $/i.test(m.text)) { 
     responses = [ 
'*اطلقق 🩵*',
     ]; 

     }else if (/^مياو|ميااو|مياااو$/i.test(m.text)) { 
     responses = [ 
'*قطة النقابة😍🫵🏻*',
'*قطتي😉*'
     ]; 
     }else if (/^شايف|شفت|شوف$/i.test(m.text)) { 
     responses = [ 
'*شفت شو بسوي يعني🌚✨*',
     ]; 
 }else if (/^حقين نقابات$/i.test(m.text)) { 
     responses = [ 
'*مفيش غيرك*',
     ]; 
 }else if (/^قول مي*او|قول ميا*و|قول مياو$/i.test(m.text)) { 
     responses = [ 
'*ما اتشبه بالقطط*',
      '*اهلك قالو اني قط*', 
      '*جرب قولها انت اول*', 
     ]; 
 }else if (/^شو$/i.test(m.text)) { 
     responses = [ 
'*ابعث مياو خاص 😖*',
'*مدري*'
     ]; 
 }else if (/^بعترف|بعترف لها$/i.test(m.text)) { 
     responses = [ 
'*مين قال بيقبلو بيك😩❤‍🔥*',
     ]; 
   }else if (/^تعترف$/i.test(m.text)) { 
     responses = [ 
'*اوووف امتى تتزوج 😂😁*',
   ]; 
   }else if (/^قادح|مسوي قادح$/i.test(m.text)) { 
     responses = [ 
'*تعليمك*',
'*بتمزح صح🙂💔*',
'*ما ادري كيف تراه كيوت 🙃💔*',
]; 
   }else if (/^دز$/i.test(m.text)) { 
     responses = [ 
'*😔☝️*',
'*اماا ما توقعت 😞*',
'*راقب تحت🙄*',   ]; 

     }else if (/^نورك$/i.test(m.text)) { 
     responses = [ 
       '*انت الاساس🌚♥*',  
     ]; 
   }else if (/^متت|متتت|متتتت|متتتتت$/i.test(m.text)) { 
     responses = [ 
'*بتكذب😔☝️*',
'*ليش تسلك🥺*',
     ]; 
     }else if (/^💋|🫦|😘$/i.test(m.text)) { 
     responses = [ 
       '*فديت البوسة 🫦*',
      '*اوف قربت اذوب 🫠*',
      '*احلى منك ما في🥹*',
'*💋🫦*',
'*بذوب وبوستك ما تخليني اتوب💋*' 

     ];
     }else if (/^ايانو$/i.test(m.text)) { 
     responses = [ 
       'الدوق', 
        'الزنجي',  
       

     ];
     }else if (/^ساكو$/i.test(m.text)) { 
     responses = [ 
     '*دير بالك يتحرش بيك🐤*',
      '*اويليي لا تقول محتاج يتحرشو بيك*',
'*ممكن النمبر يا عنبر*', 

     ];

   }

   // === ردود إضافية مضافة بنفس الصيغة كما طلبت ===
   else if (/^شو$/i.test(m.text)) {
     responses = [
       '*اضربو على وش😂و*',
       '*ما لازم تعرف🌚*'
     ];
   } else if (/^فديت$|^فديتك$/i.test(m.text)) {
     responses = [
       '*افداك*',
       '*فداك الكون يا محوره🥺!*'
     ];

   } else if (/^ياويلي$|^اويلي$/i.test(m.text)) {
     responses = [
       '*حلوة صح🐤*',
       '*شكلي صرت اعرف 😺*'
     ];
   } else if (/^دوم$|^دوووم$/i.test(m.text)) {
     responses = [
       '*🙏بدوامك*',
       '*نبضك 🍧*'
     ];
   } else if (/^باكل$|^بروح اكل$/i.test(m.text)) {
     responses = [
       '*صحة وهنا*',
       '*صحة على قلبك*'
     ];
   }
   // === نهاية الردود الإضافية ===

   if (responses) { 
     let randomIndex = Math.floor(Math.random() * responses.length); 
     conn.reply(m.chat, responses[randomIndex], m); 
   } 
   return !0 
 }; 

 export default handler;